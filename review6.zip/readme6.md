# CodeFirstCppDB — reliability and adoption plan

Reviewed **16 November 2026**, source commit **`4bfd869907a2e5069ef034b8722f33a6aded9c0b`**.

This is a public-facing review and proposed implementation plan for a reusable C++26 database library for applications and games. **SQLite is the first supported backend; MySQL is the next priority.** This document does not implement the proposed production fixes. The accompanying [review6](review6/README.md) directory contains independent regression checks and an installed-package consumer.

## 1. Assessment and evidence

The project has a useful foundation: separate Core/DAL/sample targets, named modules, compile-time mapping, explicit strong IDs, composable queries, SQLite foreign-key enforcement, transaction/savepoint helpers, and 85 existing tests. Preserve those capabilities. The next milestone should establish reliable failure semantics and straightforward external consumption before expanding the feature surface.

Evidence labels used below:

- **Runtime reproduced:** executed against the reviewed code; a supplied regression assertion failed or a sanitizer detected invalid memory access.
- **Source finding:** directly supported by a code path, but no dedicated runtime reproduction was completed.
- **Contract decision:** an observed behavior whose intended API semantics must be specified and then enforced.
- **Planned qualification:** recommended work, not a claim that a defect or performance improvement has been measured.

The isolated Linux x86-64 test environment used GCC/libstdc++ **16.2.0**, CMake **4.4.4**, Ninja and SQLite **3.46.1**. Source files were mounted read-only and all databases/build products were disposable. The 85 original tests passed in the initial clean Debug build. Additional results are recorded below. This is not Windows/macOS, MySQL, Release, full-library sanitizer, crash-recovery, or performance qualification.

| Check | Observed result |
| --- | --- |
| External source consumer (`add_subdirectory`), with explicit C++26/module settings | Built successfully |
| Existing behavioral suite, repeated in the external harness | **85/85 passed** |
| Additional behavior/contract checks | **14/14 failed their intended safety assertions**, with the observations below |
| Lifetime diagnostics | **2/2 detected invalid access:** `dangling` produced ASan heap-use-after-free; `escaped_query` produced ASan stack-use-after-return |
| Installed-package consumer | **Passed:** configured, built and ran successfully (exit 0) using the installed prefix |

| ID / regression case | Reproduced observation | Interpretation |
| --- | --- | --- |
| R01 `tracked_transaction` | Callback returned success; tracked edit was not persisted | Integrity defect |
| R02 `rollback_retry` | Save after explicit rollback omitted the edited value | Rollback/retry contract gap |
| R03 `failed_batch_retry` | Second update failed; after removing the failure and retrying, the first edit remained unsaved | Integrity defect in failed-save recovery |
| R04 `abandoned_scope` | A deferred insertion from an abandoned outer scope was saved later | Scope/queue rollback inconsistency; define cancellation policy |
| R05 `missing_bind` | Missing binding was accepted as NULL | Contract-hardening decision; legal SQLite behavior |
| R06 `empty_blob` | Empty binary vector became SQL NULL | Value-preservation defect |
| R07 `sql_tail` | Prepared execution reported success but ignored the second statement | Contract-hardening decision; legal SQLite preparation behavior |
| R08 `raw_transaction` | Raw BEGIN left the wrapper reporting no transaction | State-consistency defect |
| R09 `savepoint_name` | An identifier containing a quote executed an additional CREATE TABLE | SQL injection through the public savepoint-name API |
| R10 `limited_delete` | A query limited to one row deleted all three matching rows | Mutation contract defect; reject or honor pagination |
| R11 `fallback_read` | Adapter fallback ignored WHERE and returned both rows | Capability/query correctness defect |
| R12 `fallback_delete` | Adapter fallback deleted both rows when only one ID was selected | Destructive correctness defect |
| R13 `rowid_overflow` | A generated ID above INT32_MAX was accepted into an int32 entity | Checked-conversion defect |
| R14 `composite_key` | Two unequal composite keys produced the same identity-map display string | Encoding collision reproduced; full wrong-row lookup inferred from source |

The lifetime cases add R15 (`dangling`, heap-use-after-free) and R16 (`escaped_query`, stack-use-after-return), both runtime reproduced with ASan and exit status 1.

The 14 additional assertions ran in 0.09 seconds; the repeated original suite ran in 2.11 seconds. These are test-run timings, not performance benchmarks. No production sources were changed to obtain these results.

The new tests intentionally assert safer behavior and are expected to fail on this revision. They are isolated from the project's normal CMake entry point. Do not invert their expectations merely to make the existing implementation pass. For cases allowing either rejection or execution, choose one supported contract and tighten the test accordingly.

## 2. P0: transaction and ownership correctness

### 2.1 Keep database state, queued operations and tracking baselines consistent

Relevant sources: [DbContext save_changes and transaction](DAL/context/DbContext.ixx), especially lines 864–934 and 1038–1157; [DbSet tracking](DAL/context/DbSet.ixx), especially lines 2370–2405.

- An individual successful update currently replaces its tracking baseline before the enclosing transaction commits. A later failure or outer rollback restores the database but not that baseline. Preserve original baselines until the owning transaction commits, or maintain a rollback journal for tracker state. A retry must not silently omit an unsaved edit.
- The outer `transaction(fn)` path only calls `save_changes()` if pending operations already exist. Dirty tracked objects are discovered inside `save_changes()`, so a callback containing only tracked mutations can complete without persisting them. Run change detection consistently on every successful completion path.
- `save_changes()` clears pending work before commit succeeds. Define behavior for commit failure, rollback failure, exceptions and uncertain commit outcomes. Keep retryable work recoverable and distinguish an unusable connection from an ordinary constraint failure. Do not report success when transaction state is uncertain.
- `save_changes()` itself needs an exception-safe transaction guard: allocation, user mapping or queued callbacks can throw. Cleanup must work outside the higher-level `transaction(fn)` helper too.
- Scope rollback/destruction must remove operations staged by that scope. The outer `TransactionScope` currently rolls back SQL without truncating its queued operations; a later save can resurrect a canceled insertion. Record entry state for both outer and nested scopes and preserve only pre-existing work according to an explicit contract.
- Specify whether rollback restores in-memory values or preserves edited drafts while marking them unsaved. Both are defensible contracts; losing edits silently is not. Specify how `discard_changes()`, refresh and detach interact with tracked objects.
- Make range mutations atomic within an existing transaction as well as outside one. `add_range_returning()` needs a savepoint or explicitly documented partial-success behavior when an outer transaction already exists.

**Acceptance:** tests for tracked-only callbacks, update-then-rollback-then-retry, mid-batch failure after a successful tracked update, abandoned scopes with deferred operations, nested failures, failed commit/release/rollback, and exceptions. Verify both persisted rows and subsequent behavior of the same context.

### 2.2 Eliminate dangling references and callbacks

Relevant sources: [DbSet constructors/query/tracked references](DAL/context/DbSet.ixx), lines 1240–1297, 1777–1796 and 2132–2179.

- A connection-only `DbSet` has no owning identity map. `find_tracked_ref()` can return a reference to an object destroyed with its local `shared_ptr`. Make this operation unavailable without a tracking owner, return an owning handle, or provide stable storage with an explicit lifetime.
- Queries and sets copy callbacks that capture a raw context pointer. Keeping a connection/repository alive does not keep that context alive. An escaped query must fail safely, own suitable independent state, or be prevented from escaping by an enforceable API design.
- Define invalidation when objects are untracked, the tracker is cleared, a connection is closed, a query performs bulk changes, or a context is destroyed. Merely documenting `optional<T&>` as non-owning does not make an immediately dangling return valid.
- Retire the deprecated borrowed `track(Domain&)` path or enforce its lifetime contract. Prefer value-owned tracking for general use.
- Make `raw_connection()` after `close()` a checked operation or enforce an explicit precondition; it currently dereferences an empty optional.

**Acceptance:** ASan cases for standalone tracked-reference lookup, escaped queries/sets, tracker clear and detach, context destruction, and closed connections. Cover tracking enabled/disabled and connection-only construction.

### 2.3 Use actual identity keys

[DbSet](DAL/context/DbSet.ixx), lines 2243–2245, uses formatted text as the identity-map key. [Core/Key.ixx](Core/Key.ixx), lines 231–239, formats composite parts without escaping or lengths. Distinct string tuples such as `("a, b", "c")` and `("a", "b, c")` therefore collide.

Use typed keys with correct equality/hash semantics. If type erasure is retained, separate display formatting from collision-free identity encoding. Test string, numeric, heterogeneous and empty key parts, delimiter characters, embedded NULs and repeated lookups of two distinct database rows. The supplied test proves the formatter collision; add a full two-row identity-map regression as part of the fix.

## 3. P0/P1: query semantics and SQLite boundary safety

### 3.1 Never silently discard a query restriction

[DbQuery::try_to_vector](DAL/context/DbSet.ixx), lines 502–525, falls back to `try_get_all()` when an adapter lacks SQL-query execution. This drops filters, ordering and pagination. The fallback `remove_where()` then deletes those unfiltered results. The existing mock makes this testable without a second server.

Introduce explicit connection capability contracts for CRUD, queries, bulk writes, transactions and savepoints. An unsupported operation must fail at compile time or return an unsupported-operation error. If an in-memory fallback is offered, it must preserve the complete query semantics and be explicitly selected. The current [DatabaseConnection concept](DAL/repositories/GenericRepository.ixx) only checks `is_open()`.

SQLite bulk delete/update currently forwards the predicate but ignores query limit, offset and ordering ([DbSet](DAL/context/DbSet.ixx), lines 1028–1097). Either reject these modifiers for bulk mutations or target the exact selected primary keys. Do not let a preview of one row become a mutation of all matching rows. Add affected-row counts and tests for updates as well as deletes.

Bulk operations also clear all tracking for the entity type. Define invalidation precisely and preserve unrelated dirty edits; silently detaching other edited objects is unsuitable for long-lived application contexts.

### 3.2 Validate and quote identifiers separately from values

[SQLiteConnection](DAL/context/SQLiteConnection.ixx), lines 750, 764 and 778, interpolates public savepoint names inside quotes without escaping. A name containing a quote and SQL statements can escape that identifier. Internal generated names are not the vulnerable case.

Prefer opaque generated savepoint handles. Otherwise validate supported identifier syntax or escape embedded quotes correctly. Centralize identifier handling for table, column, index, savepoint and schema names. Bind values through prepared statements. Clearly label intentionally raw SQL APIs, and never treat raw fragments or annotation text as validated merely because their C++ types compile.

**Acceptance:** harmless in-memory tests containing quotes, semicolons, comment markers, Unicode and reserved words must either preserve the intended identifier or reject it before execution.

### 3.3 Make dynamic statement contracts explicit

Relevant source: [SQLiteConnection query_rows, execute_prepared and bind_dynamic_params](DAL/context/SQLiteConnection.ixx), lines 916–1099.

- Preserve the difference between SQL NULL and an empty BLOB. A null pointer passed to `sqlite3_bind_blob` represents NULL; use a valid empty-BLOB operation, such as `sqlite3_bind_zeroblob(..., 0)`, when the vector is empty.
- Validate supplied bindings. Missing positional parameters currently become NULL. Decide whether partial binding is ever allowed, and require an explicit mode if it is. Include repeated named parameters and sparse numbered placeholders in the design; a naive placeholder count is not enough for every SQL form.
- Inspect the prepare tail. The prepared APIs currently execute only the first statement and silently ignore the rest. Prefer rejecting trailing executable SQL and providing a separate explicit script API. Handle comments, whitespace, embedded NULs and empty SQL deliberately.
- Decide whether `execute_prepared()` rejects result-producing statements or drains them to completion. Stopping at the first `SQLITE_ROW` does not establish complete execution. Preserve errors from stepping/finalization.
- Check SQL, text, BLOB and index sizes before `size_t` to `int` conversion; use SQLite's 64-bit binding APIs where appropriate. Enforce configurable resource limits instead of requiring multi-gigabyte tests in normal CI.

SQLite's [binding contract](https://sqlite.org/c3ref/bind_blob.html) defines null-pointer and length behavior. Its [prepare contract](https://sqlite.org/c3ref/prepare.html) explicitly compiles only the first statement and exposes the unconsumed tail.

### 3.4 Derive transaction state from the engine

The cached `in_transaction_` flag can disagree with raw `BEGIN`/`ROLLBACK` or engine-triggered automatic rollback. Inspect actual state through [sqlite3_get_autocommit](https://sqlite.org/c3ref/get_autocommit.html); track scope ownership separately. Define how raw transaction control interacts with managed scopes, or reject that combination explicitly.

Verify effective PRAGMA values. Executing `journal_mode=WAL` successfully does not mean WAL was selected, especially for an in-memory database. Foreign-key settings must be verified when wrapping existing connections as well as opening new ones. Return/report effective journal, synchronization, timeout and FK settings.

### 3.5 Check generated and mapped values

[MapperTraits](DAL/mappers/MapperTraits.ixx), lines 410–435, narrows SQLite's generated 64-bit row ID to the entity's key type without checking the range. Validate representability and ensure a rejected hydration does not leave an inaccessible inserted row. Cover signed/unsigned boundaries, int32/int64 IDs and strong wrappers on both writes and reads.

Do not use constructibility or `static_cast` as proof of lossless mapping. Validate enums, numeric conversions and user construction failures. Translate expected mapping/validation failures into structured errors, while documenting allocation exceptions and other exceptional behavior separately.

## 4. P1: predictable schema and migration support

`ensure_created()` creates missing objects; it is not a schema migration or compatibility check. Name and document that distinction clearly.

- Generate real composite PRIMARY KEY constraints. A separate UNIQUE index is not interchangeable with a declared primary key for schema introspection or every backend. Keep key membership explicit instead of guessing that foreign keys form a primary key.
- Document self-referencing and cyclic FK support. A topological-sort rejection is a library limitation, not proof that the underlying engine cannot represent the schema; offer a supported creation/migration strategy or an explicit diagnostic.
- Support stable table/column names, column ordering where relevant, defaults, nullability, named constraints, indexes and partial-index predicates. Specify FK actions, generated values, supported CHECK constraints, collations and trigger handling.
- Add read-only schema inspection/diff with explicit compatibility diagnostics. Reject incompatible existing tables instead of treating `IF NOT EXISTS` as successful validation.
- Introduce an explicit migration ledger and versioned migration API, preserving application-owned SQL where required. Keep destructive operations opt-in; provide backup/restore guidance and recovery tests.
- For SQLite rebuild migrations, preserve indexes, triggers, FK behavior and data, then run integrity/FK checks. Test interrupted upgrades and reopening old fixtures.
- Offer atomic conditional updates and affected-row checks for optimistic concurrency. Applications should be able to implement version checks, audit writes and soft deletion explicitly; reflection must not invent these business policies.

The pinned sqlgen `insert_or_replace` uses `ON CONFLICT ... DO UPDATE` in its SQLite SQL generator. Do not diagnose it as SQLite's delete-and-reinsert `REPLACE` merely from the API name. Test the actual generated SQL and its key/constraint semantics.

## 5. P1: packaging, build integration and support policy

Relevant sources: [root CMake](CMakeLists.txt), [Core target](Core/CMakeLists.txt), [package config](cmake/CodeFirstCppDBConfig.cmake.in), [CI](.github/workflows/ci.yml).

1. Preserve and extend the now-tested installed-consumer path. The simple `find_package` consumer **configured, built and ran successfully on CMake 4.4.4**; CMake synthesized module interfaces from the installed source file sets. Absence of `CXX_MODULES_DIRECTORY` is therefore **not a reproduced package failure in this configuration**. Review explicit module export metadata against [CMake's export documentation](https://cmake.org/cmake/help/v4.4/command/install.html#export), and qualify every supported CMake/toolchain combination. Add a relocated installed-package test, custom entity/query template instantiation, and tests with original sources/build artifacts unavailable. The current smoke test imports modules and opens a connection; it does not establish all those broader guarantees.
2. Express `cxx_std_26` and required reflection/contracts configuration through target usage requirements. Directory-local `CMAKE_CXX_STANDARD` alone does not configure a parent consumer. Preserve unrelated targets' standards and options.
3. Support explicit bundled and system-package modes, canonical namespaced dependency targets, and applications already using sqlgen/reflect-cpp. Remove synthetic empty dependency config files and unnecessary forced cache/global include overrides.
4. Use distinctive project-owned module names instead of globally generic `core`/`dal`; introduce a documented migration path. Preserve exported templates/reflection reachability and test separate importing consumers.
5. Replace reflection into sqlgen's private `conn_` member with a supported upstream native-handle API or an explicitly pinned adapter contract (`SQLiteConnection.ixx`, lines 1102–1122). Private-member spelling is not a stable dependency interface.
6. Test static and shared builds separately. Qualify symbol visibility/export behavior, runtime dependencies and module metadata for each claimed platform. A static Linux build does not qualify Windows DLL distribution.
7. Publish exact validated compiler, libstdc++, CMake and Ninja combinations. GCC compiled module interfaces are [version-dependent caches](https://gcc.gnu.org/onlinedocs/gcc/C_002b_002b-Compiled-Module-Interface.html), not portable binary interfaces. Separate artifacts by toolchain, platform, configuration and relevant options.
8. Correct README's CMake 3.30 claim, incomplete consumer snippets and CI's nonexistent `CODEFIRST_BUILD_SAMPLES` option. Use `CODEFIRST_BUILD_EXAMPLES`/`CODEFIRST_INCLUDE_SAMPLES`. Execute README examples in CI.
9. Pin/verify build tools and formatter, qualify contracts ON/OFF, and keep vendor suppressions local. Add clean and incremental builds, external `add_subdirectory`, FetchContent with pinned revisions, installed consumers and dependency co-existence tests.
10. Add a project-owned license and installed notices; inventory enabled/transitive dependencies and publish versioned releases. Public availability alone does not specify redistribution terms.

## 6. C++26 and current GCC: use modern features deliberately

As of this review, [GCC's release list](https://gcc.gnu.org/releases.html) identifies **16.2** as the newest release in the newest stable major series. Use a tested stable baseline and an additional newest-development-GCC lane for early diagnostics; do not confuse experimental feature support with production qualification.

- Keep standard reflection, annotations, named modules, strong types, `std::expected`, expansion statements and constructor-based hydration. Add compile/link probes for the actual combinations used, including imported reflection and annotations across module boundaries.
- Qualify CMake 4.5's current `import std` support. Retain version-specific handling for older supported CMake releases rather than blindly applying one experimental UUID. See [current CMake module support](https://cmake.org/cmake/help/latest/manual/cmake-cxxmodules.7.html).
- Make mapping opt-in and persistent names stable. Unchecked private-member writes must require an explicit supported policy; falling back silently when no valid constructor exists can bypass domain invariants. Detect ambiguous constructor mapping and distinguish absent, null and default values.
- Complete move-only task support end to end. `pending_ops_` uses `std::move_only_function`, but `enqueue_op` and DbSet callback boundaries still require `std::function`. Remove unnecessary copyability requirements where ownership is transferred.
- Use `std::function_ref` only for callbacks that cannot escape. It is not a replacement for owning queued work. Use `std::optional<T&>` only with a demonstrated valid referent lifetime.
- Consider `std::inplace_vector`, allocator-aware containers, pack indexing and other supported facilities when they simplify a concrete implementation. Document bounds and overflow behavior. Do not add them simply to increase feature usage.
- Contracts should diagnose programmer errors. Untrusted SQL/data, disconnected databases, lock contention and validation failures need ordinary error handling. Test public imports with contracts enabled and disabled.
- Remove duplicated reflection/string-literal helpers, document access policy, and prefer qualified supported library facilities over custom compatibility machinery where they reduce maintenance.

## 7. P1/P2: API usability for applications and games

- Choose one coherent write model. Prefer predictable staged unit-of-work operations with clearly named immediate/bulk alternatives, or make the mode explicit in types. Avoid behavior that silently changes with hidden context state.
- Make fallible APIs return `[[nodiscard]] std::expected` consistently. Deprecate or explicitly name wrappers that turn errors into empty rows/zero/false. Provide fallible tracked lookups too.
- Preserve native error codes and context throughout upsert/bulk paths. Complete the existing Task 47 work: strong-ID `find_tracked_ref` constraints, native error mapping, consistent Debug traces, remaining `[[nodiscard]]` attributes and documentation fixes.
- Expose affected-row counts and distinguish not-found, stale/conflicting update, invalid input, unavailable backend capability, busy/locked, canceled, constraint and connection failures. Avoid logging bound secrets; make expensive stack traces optional.
- Rename full-table predicate helpers to make in-memory filtering explicit. Explain server-side predicates, NULL comparisons, ordering, pagination, projection, key generation and tracking refresh behavior with short examples.
- Support bounded/streaming/chunked reads, keyset pagination and span/range-friendly batch writes. Add cancellation/deadlines and clear partial-result semantics. Avoid forcing every large read through complete DTO and domain vectors.
- Document one owner for each context/connection and a safe worker-queue integration pattern. Database work must not unexpectedly block a UI/render thread. Define bounded queues, cancellation, shutdown and connection lifetime; avoid detached tasks referencing destroyed state.
- Keep tracking optional for read-heavy workloads, tools, asset catalogs and gameplay loading. Provide clear non-tracking APIs and measure their allocation behavior.
- Document file locations/permissions, read-only/open-existing modes, explicit create behavior, backup and safe shutdown. Make destructive sample resets explicit and opt-in; include a reopen/no-reset example.
- Publish a small capability matrix covering platform, backend, schema features, transactions and packaging, with unqualified items marked honestly. Consolidate old phase/review notes so new consumers see current behavior first.

## 8. Performance program: measure before promising

No performance benchmark was run for this review. Fast unit-test execution is not evidence of scalable throughput, bounded frame time or low memory use.

Create a repeatable C++ benchmark target comparing direct SQLite, sqlgen and the public library API. Record compiler/runtime versions, optimization flags, SQLite build options, hardware, data shape, transaction sizes and cache state.

| Workload | Required dimensions |
| --- | --- |
| Inserts/updates/deletes | Single row and 1,000/100,000-row batches; explicit transaction vs per-operation commit; generated and assigned keys |
| Reads | Point lookup, filtered scans, projections, large-offset vs keyset pagination, warm/cold preparation, bounded streaming |
| Data/tracking | Small scalars, large text/BLOBs, NULL/empty values, tracking on/off, DTO/domain conversion |
| Storage/concurrency | `:memory:` and real files; WAL and rollback journals; multiple connections, lock contention, checkpoints and cancellation |
| Build/adoption | Clean/incremental/module rebuild time, dependency changes, binary size and consumer compile cost |

Report throughput and p50/p95/p99 latency, allocations, peak memory, SQL statement/commit counts and database/WAL size. Include reproducible datasets and results, not only a headline number.

Investigate prepared-statement reuse with bounded caches and schema invalidation; typed identity maps; fewer transient strings/type-erased callbacks; and fewer DTO/domain copies. Only retain an optimization after measuring benefit and checking semantic equivalence. Evaluate LTO/PGO separately from sanitizer/diagnostic builds. Preserve durability defaults rather than using unsafe PRAGMAs to improve benchmark scores.

## 9. SQLite release qualification and security maintenance

- Record SQLite runtime version, source/build provenance, enabled extensions and security patches. Test both the oldest supported patched release and a current supported release.
- SQLite's [WAL documentation](https://sqlite.org/wal.html#the_wal_reset_bug) describes a WAL-reset corruption race affecting concurrent writers/checkpoints, fixed in 3.51.3 and selected backports including 3.44.6 and 3.50.7. The test runtime reported 3.46.1; its package patch provenance was not audited here. Require evidence of the fix before qualifying affected WAL deployments. This is a dependency qualification issue, not a reproduced corruption result from this review.
- Add file-backed tests for busy timeouts, WAL checkpoints, concurrent readers/writers, crash/reopen behavior, migrations, backups and read-only files. SQLite serialization does not make the library's tracker thread-safe.
- Define byte/row/time limits for untrusted or oversized data. Fuzz binding, mapping, schema names and SQL-fragment boundaries. Offer appropriate SQLite defensive settings and keep extension loading disabled unless explicitly needed.
- Exercise disk-full/I/O errors and interrupted operations through controlled fault injection where practical. Verify cleanup and error reporting without modifying users' real data.
- Add ASan/UBSan and supported concurrency checks to CI; qualify project and dependencies together. The supplied lifetime target instruments the regression executable, not the complete library/dependency closure.

## 10. MySQL: second backend, after SQLite reliability

Current status: root CMake forces `SQLGEN_MYSQL OFF`; the project has no complete MySQL adapter. An upstream driver or a PostgreSQL option does not establish public MySQL support.

### Prerequisites before enabling it

1. Implement explicit adapter capability contracts and run shared behavior tests against both engines. Unsupported SQLite-specific features must be diagnosed, never silently approximated.
2. Select supported MySQL server and connector versions; test MariaDB separately if claimed. Review connector licensing, runtime distribution and platform availability.
3. Preserve native errors/SQLSTATE and cover generated IDs, affected-versus-matched rows, upserts, unsigned ranges, decimals, binary/text/NULL values, collations, Unicode and timestamp/time-zone policy.
4. Qualify autocommit, isolation, deadlocks, lock timeouts, reconnects and unknown commit outcomes. Do not blindly retry writes after a lost connection when commit status is unknown.
5. Design migrations around engine behavior: MySQL statements can [implicitly commit](https://dev.mysql.com/doc/refman/8.4/en/implicit-commit.html), so do not promise SQLite-style atomic DDL migration semantics universally.
6. Add TLS certificate/hostname verification, explicit character-set configuration, secure credentials, connect/read/write timeouts and disabled multi-statements by default.

### Security gate in the pinned upstream driver — source finding

The pinned sqlgen MySQL SQL generator interpolates query values and escapes apostrophes by doubling them (`extern/sqlgen/src/sqlgen/mysql/to_sql.cpp`, lines 176 and 479–480). The connection uses `mysql_real_query` for reads and enables `CLIENT_MULTI_STATEMENTS`. MySQL interpretation also depends on backslash handling and SQL mode, as described in its [string-literal rules](https://dev.mysql.com/doc/refman/8.4/en/string-literals.html).

Before adopting that path, use bound query/predicate values or a rigorously qualified connector mechanism, disable unnecessary multi-statement execution, and test apostrophes, backslashes, NULs and multibyte text under every supported SQL mode/charset. Coordinate the fix upstream rather than accumulating an undocumented local fork. No live MySQL server test or exploit verification was performed here; this is not a vulnerability in the currently enabled SQLite backend.

## 11. Suggested delivery order and acceptance gates

| Increment | Scope | Evidence required before closure |
| --- | --- | --- |
| 1 — Integrity | Transaction/tracker recovery, scope rollback, ownership, identity keys, query restrictions | Focused regressions pass; original 85 tests remain green; sanitizer lifetime failures eliminated |
| 2 — SQLite boundary | Savepoint identifiers, binding/statement contracts, checked conversions, transaction state | Raw/dynamic/typed parity tests; range/error tests; file-backed failure and concurrency coverage |
| 3 — Consumer readiness | Package qualification, transitive options, dependency modes, licensing, current docs | Clean external source consumer and relocated installed consumer; no hidden source-tree dependency |
| 4 — Stable app API | Clear write/error/lifetime contracts, migration hooks, conditional writes, bounded reads | Reopen/upgrade fixtures; documented recovery, cancellation and thread-ownership examples |
| 5 — Performance | Repeatable workloads and measured improvements | Published baseline and comparative latency/allocation/memory results with identical semantics |
| 6 — MySQL | Secure adapter and dialect behavior | Real-server shared conformance suite, TLS/SQL-mode tests, migration and failure-recovery qualification |

Keep each increment reviewable. Track findings by stable IDs and expected behavior, not only phase numbers. Re-run the relevant tests when fixing a defect; broaden testing where a change affects transaction, mapping, packaging or backend-wide behavior. Record any remaining limitation with its affected versions, reason, evidence and removal condition.



