import std;
import core;
import dal;

int main()
{
    auto connection = DAL::SQLiteConnection::connect(":memory:");
    return connection ? 0 : 1;
}
