#include <sqlgen.hpp>
#include <sqlgen/sqlite.hpp>

import std;
import core;
import dal;
import samples;

#include "TestSupport.hpp"

namespace Review6
{
    struct MockContext : DAL::DbContextBase<TestDatabaseConnection>
    {
        Set<Core::Person> people{this};

        explicit MockContext(std::shared_ptr<TestDatabaseConnection> connection)
            : DAL::DbContextBase<TestDatabaseConnection>(std::move(connection))
        {
        }
    };
    void require(bool condition, std::string_view message)
    {
        if (!condition)
        {
            throw std::runtime_error(std::string(message));
        }
    }

    template<typename T>
    T take(std::expected<T, Core::DbError> result)
    {
        if (!result)
        {
            throw std::runtime_error(result.error().to_string());
        }
        if constexpr (!std::is_void_v<T>)
        {
            return std::move(*result);
        }
    }

    std::string stored_name(const std::shared_ptr<DAL::SQLiteConnection>& connection)
    {
        auto rows = take(connection->query_rows("SELECT first_name FROM Person WHERE id=1"));
        return std::get<std::string>(rows.rows.at(0).cells.at(0));
    }

    void run(std::string_view test)
    {
        auto connection = take(DAL::SQLiteConnection::connect(":memory:"));
        Phase30DbContext db(connection);
        take(db.ensure_created());
        take(db.people.add(Core::Person(Core::PersonId{0}, "Original", "Person")));

        if (test == "tracked_transaction")
        {
            db.enable_change_tracking();
            auto person = db.people.find_tracked(1);
            take(db.transaction([&]() { person->setFirstName("Changed"); }));
            require(stored_name(connection) == "Changed", "transaction returned success but tracked edit was not saved");
        }
        else if (test == "rollback_retry")
        {
            db.enable_change_tracking();
            auto person = db.people.find_tracked(1);
            take(db.begin_transaction());
            person->setFirstName("Changed");
            take(db.save_changes());
            take(db.rollback());
            require(stored_name(connection) == "Original", "rollback setup failed");
            take(db.save_changes());
            require(stored_name(connection) == "Changed", "retry lost the tracked edit after rollback");
        }
        else if (test == "failed_batch_retry")
        {
            take(db.people.add(Core::Person(Core::PersonId{0}, "Second", "Person")));
            db.enable_change_tracking();
            auto first = db.people.find_tracked(1);
            auto second = db.people.find_tracked(2);
            take(connection->execute_raw("CREATE TRIGGER fail_second BEFORE UPDATE ON Person WHEN NEW.id=2 BEGIN SELECT RAISE(ABORT, 'injected failure'); END;"));
            first->setFirstName("ChangedFirst");
            second->setFirstName("ChangedSecond");
            require(!db.save_changes(), "failure injection did not fail");
            require(stored_name(connection) == "Original", "failed batch did not roll back");
            take(connection->execute_raw("DROP TRIGGER fail_second"));
            take(db.save_changes());
            require(stored_name(connection) == "ChangedFirst", "failed batch accepted an uncommitted baseline and retry lost the first edit");
            auto rows = take(connection->query_rows("SELECT first_name FROM Person WHERE id=2"));
            require(std::get<std::string>(rows.rows.at(0).cells.at(0)) == "ChangedSecond", "retry lost the second edit");
        }
        else if (test == "abandoned_scope")
        {
            db.defer_changes(true);
            {
                DAL::TransactionScope<DAL::SQLiteConnection> scope(db);
                require(scope.is_active(), "scope setup failed");
                take(db.people.add(Core::Person(Core::PersonId{0}, "Canceled", "Person")));
            }
            take(db.save_changes());
            require(take(db.people.query().try_count()) == 1, "abandoned transaction resurrected its staged insertion");
        }
        else if (test == "missing_bind")
        {
            auto result = connection->query_rows("SELECT ? AS required_value");
            require(!result, "missing parameter was silently accepted as SQL NULL");
        }
        else if (test == "empty_blob")
        {
            const std::array<DAL::DynamicCell, 1> values{std::vector<std::byte>{}};

            const std::array<DAL::DynamicCell, 2> blobs{values[0], values[0]};
            auto result = take(connection->query_rows("SELECT typeof(?), length(?)", std::span<const DAL::DynamicCell>(blobs)));
            require(std::get<std::string>(result.rows.at(0).cells.at(0)) == "blob", "empty BLOB was bound as SQL NULL");
            require(std::get<std::int64_t>(result.rows.at(0).cells.at(1)) == 0, "empty BLOB length changed");
        }
        else if (test == "sql_tail")
        {
            auto result = connection->execute_prepared("CREATE TABLE first_table(id INTEGER); CREATE TABLE second_table(id INTEGER);");
            if (result)
            {
                auto rows = take(connection->query_rows("SELECT name FROM sqlite_schema WHERE name='second_table'"));
                require(!rows.rows.empty(), "prepared execution reported success but discarded the second statement");
            }
        }
        else if (test == "raw_transaction")
        {
            take(connection->execute_raw("BEGIN"));
            require(connection->in_transaction(), "raw BEGIN is not reflected in transaction state");
            take(connection->rollback());
        }
        else if (test == "savepoint_name")
        {
            auto result = connection->savepoint("safe\"; CREATE TABLE injected(id INTEGER); --");
            auto rows = take(connection->query_rows("SELECT name FROM sqlite_schema WHERE name='injected'"));
            require(rows.rows.empty(), "savepoint name executed an additional SQL statement");
        }
        else if (test == "limited_delete")
        {
            take(db.people.add(Core::Person(Core::PersonId{0}, "Second", "Person")));
            take(db.people.add(Core::Person(Core::PersonId{0}, "Third", "Person")));
            auto result = db.people.where_equal<"lastName">("Person").limit(1).remove_where();
            require(take(db.people.query().try_count()) == (result ? 2u : 3u), "limited bulk delete silently deleted every matching row");
        }
        else if (test == "fallback_read" || test == "fallback_delete")
        {
            auto mock = std::make_shared<TestDatabaseConnection>();
            MockContext mock_db(mock);
            take(mock_db.ensure_created());
            take(mock_db.people.add(Core::Person(Core::PersonId{1}, "One", "Person")));
            take(mock_db.people.add(Core::Person(Core::PersonId{2}, "Two", "Person")));
            if (test == "fallback_read")
            {
                auto result = mock_db.people.where_equal<"id">(1).try_to_vector();
                require(!result || result->size() == 1, "adapter fallback silently discarded WHERE");
            }
            else
            {
                auto result = mock_db.people.where_equal<"id">(1).remove_where();
                require(take(mock_db.people.query().try_count()) == (result ? 1u : 2u), "filtered adapter delete deleted unrelated rows");
            }
        }
        else if (test == "rowid_overflow")
        {
            take(connection->execute_raw("UPDATE sqlite_sequence SET seq=2147483647 WHERE name='Person'"));
            auto result = db.people.add_returning(Core::Person(Core::PersonId{0}, "Overflow", "Person"));
            require(!result, "64-bit generated SQLite ID narrowed into int32 without rejection");
        }
        else if (test == "composite_key")
        {
            Core::CompositeKey<std::string, std::string> first{"a, b", "c"};
            Core::CompositeKey<std::string, std::string> second{"a", "b, c"};
            require(first != second, "key setup failed");
            require(std::format("{}", first) != std::format("{}", second), "distinct composite keys share the identity-map display key");
        }
        else if (test == "escaped_query")
        {
            auto query = [&]()
            {
                Phase30DbContext local(connection);
                local.enable_change_tracking();
                return local.people.where_equal<"id">(1);
            }();
            auto rows = take(query.try_to_vector());
            require(rows.size() == 1, "escaped query lost its result");
        }
        else if (test == "dangling")
        {
            auto standalone = db.create_set<Core::Person>();
            auto reference = standalone.find_tracked_ref(Core::Person::Key{Core::PersonId{1}});
            require(reference.has_value(), "standalone lookup failed");
            volatile auto length = reference->getFirstName().size();
            require(length == 8, "standalone reference no longer owns a valid object");
        }
        else
        {
            throw std::runtime_error("unknown test case");
        }
    }
}

int main(int argc, char** argv)
{
    try
    {
        Review6::require(argc == 2, "usage: review6_regressions CASE");
        Review6::run(argv[1]);
        std::println("PASS {}", argv[1]);
        return 0;
    }
    catch (const std::exception& error)
    {
        std::println("FAIL: {}", error.what());
        return 1;
    }
}





