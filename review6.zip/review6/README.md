# Review 6 regression checks

These checks accompany [readme6.md](../readme6.md) and target source revision `4bfd869907a2e5069ef034b8722f33a6aded9c0b`. They intentionally expose unresolved behavior; they are **not a claim that the reviewed library passes these assertions**. Production sources and the normal project test registration are unchanged.

All regression databases use `:memory:`. The savepoint-name check creates only a harmless table in its disposable database. Lifetime cases intentionally exercise invalid ownership paths and should be run under AddressSanitizer.

## Build and run

The exercised environment was Linux x86-64, GCC/libstdc++ 16.2.0, CMake 4.4.4, Ninja and SQLite 3.46.1. Use the required compiler/runtime and initialized project submodules. From the repository root:

```sh
cmake -S review6 -B build/review6 -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build/review6 --parallel 2
ctest --test-dir build/review6 -E '^review6[.]' --output-on-failure
ctest --test-dir build/review6 -R '^review6[.]' --output-on-failure
```

The first CTest invocation runs the original suite. The second runs the additional regression assertions and is expected to return a nonzero status on the reviewed revision. The harness enables samples because it reuses the project's public sample entities and `DAL/tests/TestSupport.hpp`. This does not imply that ordinary consumers need samples.

To test another checkout, set `-DCODEFIRST_SOURCE_DIR=/absolute/path/to/checkout`. Keep the report's reviewed revision distinct from results against modified sources.

Run one check directly:

```sh
./build/review6/review6_regressions failed_batch_retry
```

Cases: `tracked_transaction`, `rollback_retry`, `failed_batch_retry`, `abandoned_scope`, `missing_bind`, `empty_blob`, `sql_tail`, `raw_transaction`, `savepoint_name`, `limited_delete`, `fallback_read`, `fallback_delete`, `rowid_overflow`, `composite_key`.

`missing_bind` and `sql_tail` express proposed strict public API contracts; the underlying SQLite behavior is legal. `rollback_retry` requires a reusable context after explicit rollback. `failed_batch_retry` separately verifies recovery from the library's own failed save. `composite_key` checks the identity encoding collision, not a complete two-row database lookup. Promote cases to permanent behavioral tests as their contracts are finalized.

## Lifetime diagnostics

```sh
cmake --build build/review6 --target review6_lifetime --parallel 2
ASAN_OPTIONS=detect_stack_use_after_return=1:detect_leaks=0 ./build/review6/review6_lifetime dangling
ASAN_OPTIONS=detect_stack_use_after_return=1:detect_leaks=0 ./build/review6/review6_lifetime escaped_query
```

This target instruments the test executable and its instantiated code. It is not a full ASan/UBSan build of every library and dependency. A detected invalid access is useful evidence; a passing run would not prove all ownership paths safe. Leak detection is disabled here to isolate the lifetime checks.

## Installed consumer

After building the suite, enable installation and install to a disposable prefix:

```sh
cmake -S review6 -B build/review6 -DCODEFIRST_INSTALL=ON -DCMAKE_INSTALL_PREFIX="$PWD/build/review6-prefix"
cmake --build build/review6 --parallel 2
cmake --install build/review6
cmake -S review6/package-consumer -B build/review6-consumer -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_PREFIX_PATH="$PWD/build/review6-prefix"
cmake --build build/review6-consumer --parallel 2
./build/review6-consumer/installed_consumer
```

This consumer imports `std`, `core` and `dal` and opens an in-memory database. On the reviewed revision this installed consumer configured, built and ran successfully with CMake 4.4.4. The smoke test does not establish relocatability, arbitrary entity/query template instantiation, or every supported toolchain combination. Add a relocation test with the original source/build directories unavailable and a library-only install with examples/samples/tests disabled.

CMake 4.4 needs its matching experimental `import std` gate before language detection; the harness supplies the exercised value. Qualify newer CMake releases rather than assuming all experimental gates are portable.

